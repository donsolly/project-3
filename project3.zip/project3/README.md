# Project 3

Web Programming with Python and JavaScript


The codename for this project is Foodio

The project contains one app wwhich is named orders

Within orders there are login URL, signup URL, index URL, Checkout and History URL

Users Can simply register using the signup page and they are automatically logged in...

When a user makes an order it is stored in a cart that is in my database and user can easily view cart or delete items from cart before finally making an order


The personal touch I added is the ability to see order status in history.


The requirement stated in the projects were met,

Menu: For the toppings I did an if statement to display only items or items with multiple toppings.

Adding items: Users can add and delete items from cart easily. All the items on Pinnochio was added. Admin can also add more items in the future from the admin dashboard

Registration, login, logout = All implemented using django default login system

SHopping cart: Users can view everything in their shopping cart till they make order before it deletes from the shopping cart. A seperate table handles that function

Viewing orders: Users can view order history easily


Personal touch: Users can see the status of their order and know when it is completed.


I really enjoyed working on this project.
